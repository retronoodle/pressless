-- Stead SQLite dump
-- generated_at: 2026-08-12 20:14:29
-- sqlite_version: 3.53.1
PRAGMA foreign_keys=OFF;


-- Table: backups
DROP TABLE IF EXISTS "backups";
CREATE TABLE backups (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    target TEXT NOT NULL,
    storage_key TEXT NOT NULL,
    size_bytes INTEGER NOT NULL DEFAULT 0,
    status TEXT NOT NULL,
    triggered_by TEXT NOT NULL,
    error_message TEXT NULL,
    created_at TEXT NOT NULL
);
INSERT INTO "backups" ("id", "target", "storage_key", "size_bytes", "status", "triggered_by", "error_message", "created_at") VALUES ('1', 'local', 'stead-backup-20260812_201321-4cf1df.zip', '0', 'pending', 'manual', NULL, '2026-08-12 20:13:21');
INSERT INTO "backups" ("id", "target", "storage_key", "size_bytes", "status", "triggered_by", "error_message", "created_at") VALUES ('2', 'local', 'stead-backup-20260812_201338-5a3e16.zip', '0', 'success', 'manual', NULL, '2026-08-12 20:13:38');
INSERT INTO "backups" ("id", "target", "storage_key", "size_bytes", "status", "triggered_by", "error_message", "created_at") VALUES ('3', 'local', 'stead-backup-20260812_201429-1610b2.zip', '0', 'success', 'manual', NULL, '2026-08-12 20:14:29');
-- (rows: 3)

-- Table: collections
DROP TABLE IF EXISTS "collections";
CREATE TABLE collections (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    slug TEXT NOT NULL,
    name TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    schema_definition TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
-- (rows: 0)

-- Table: entries
DROP TABLE IF EXISTS "entries";
CREATE TABLE entries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    collection_id INTEGER NOT NULL,
    slug TEXT NOT NULL,
    title TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'draft',
    author_id INTEGER NULL,
    published_at TEXT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY (collection_id) REFERENCES collections(id) ON DELETE CASCADE,
    FOREIGN KEY (author_id) REFERENCES users(id) ON DELETE SET NULL
);
-- (rows: 0)

-- Table: entry_values
DROP TABLE IF EXISTS "entry_values";
CREATE TABLE entry_values (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    entry_id INTEGER NOT NULL,
    field_key TEXT NOT NULL,
    field_type TEXT NOT NULL DEFAULT 'text',
    value TEXT NOT NULL,
    value_index TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL, value_text TEXT NULL, value_number REAL NULL, value_date TEXT NULL, value_bool INTEGER NULL, value_json TEXT NULL,
    FOREIGN KEY (entry_id) REFERENCES entries(id) ON DELETE CASCADE
);
-- (rows: 0)

-- Table: invites
DROP TABLE IF EXISTS "invites";
CREATE TABLE invites (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT NOT NULL,
    role_id INTEGER NOT NULL,
    token_hash TEXT NOT NULL,
    expires_at TEXT NOT NULL,
    accepted_at TEXT NULL,
    revoked_at TEXT NULL,
    created_by INTEGER NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE RESTRICT,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
);
-- (rows: 0)

-- Table: login_attempts
DROP TABLE IF EXISTS "login_attempts";
CREATE TABLE login_attempts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT NOT NULL,
    ip_address TEXT NOT NULL,
    succeeded INTEGER NOT NULL DEFAULT 0,
    cleared_at TEXT NULL,
    created_at TEXT NOT NULL
);
-- (rows: 0)

-- Table: mail_settings
DROP TABLE IF EXISTS "mail_settings";
CREATE TABLE mail_settings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    host TEXT NOT NULL DEFAULT '',
    port INTEGER NOT NULL DEFAULT 587,
    encryption TEXT NOT NULL DEFAULT 'starttls',
    username TEXT NOT NULL DEFAULT '',
    password TEXT NOT NULL DEFAULT '',
    updated_at TEXT NOT NULL
);
-- (rows: 0)

-- Table: media
DROP TABLE IF EXISTS "media";
CREATE TABLE media (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    filename TEXT NOT NULL,
    mime_type TEXT NOT NULL DEFAULT '',
    size_bytes INTEGER NOT NULL DEFAULT 0,
    path TEXT NOT NULL,
    uploaded_by INTEGER NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY (uploaded_by) REFERENCES users(id) ON DELETE SET NULL
);
-- (rows: 0)

-- Table: migrations
DROP TABLE IF EXISTS "migrations";
CREATE TABLE migrations (
                    version TEXT PRIMARY KEY,
                    applied_at TEXT NOT NULL
                );
-- (rows: 0)

-- Table: permissions
DROP TABLE IF EXISTS "permissions";
CREATE TABLE permissions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    role_id INTEGER NOT NULL,
    collection_id INTEGER NOT NULL,
    action TEXT NOT NULL,
    UNIQUE (role_id, collection_id, action),
    FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE CASCADE,
    FOREIGN KEY (collection_id) REFERENCES collections(id) ON DELETE CASCADE
);
-- (rows: 0)

-- Table: revisions
DROP TABLE IF EXISTS "revisions";
CREATE TABLE revisions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    entry_id INTEGER NOT NULL,
    author_id INTEGER NULL,
    payload TEXT NOT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY (entry_id) REFERENCES entries(id) ON DELETE CASCADE,
    FOREIGN KEY (author_id) REFERENCES users(id) ON DELETE SET NULL
);
-- (rows: 0)

-- Table: roles
DROP TABLE IF EXISTS "roles";
CREATE TABLE roles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE
);
-- (rows: 0)

-- Table: schema_change_log
DROP TABLE IF EXISTS "schema_change_log";
CREATE TABLE schema_change_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    collection_id INTEGER NOT NULL,
    previous_field_set_hash TEXT NULL,
    new_field_set_hash TEXT NOT NULL,
    applied_at TEXT NOT NULL,
    FOREIGN KEY (collection_id) REFERENCES collections(id) ON DELETE CASCADE
);
-- (rows: 0)

-- Table: sessions
DROP TABLE IF EXISTS "sessions";
CREATE TABLE sessions (
    id TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL,
    ip_address TEXT NOT NULL DEFAULT '',
    user_agent TEXT NOT NULL DEFAULT '',
    payload TEXT NOT NULL,
    last_activity TEXT NOT NULL,
    expires_at TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
-- (rows: 0)

-- Table: users
DROP TABLE IF EXISTS "users";
CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT NOT NULL,
    name TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    is_active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
, role_id INTEGER NULL);
-- (rows: 0)

PRAGMA foreign_keys=ON;
